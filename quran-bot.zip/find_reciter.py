# يبحث عن اسم المجلد الصحيح للقارئ على EveryAyah
# الاستخدام:  python find_reciter.py          (يطبع الكل)
#             python find_reciter.py mossad   (يبحث بكلمة)
import re, sys, requests
t = requests.get("https://everyayah.com/data/recitations.js", timeout=30).text
rows = re.findall(r'"name"\s*:\s*"([^"]+)"[^{}]*?"subfolder"\s*:\s*"([^"]+)"', t)
q = sys.argv[1].lower() if len(sys.argv) > 1 else ""
hits = [(n, f) for n, f in rows if q in n.lower() or q in f.lower()]
if not rows:
    hits = [(l, "") for l in t.splitlines() if q in l.lower()]
for n, f in hits:
    print(f"{n}  ->  {f}")
if not hits:
    print("ما لقيت قارئ بهذا الاسم على EveryAyah")
