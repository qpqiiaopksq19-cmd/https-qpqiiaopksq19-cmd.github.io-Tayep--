# خطوات التشغيل

1. ارفع هذا المجلد كله على ريبو GitHub جديد (فرع main).
2. فعّل الموقع: Settings ← Pages ← Deploy from branch ← main ← / (root). رابط موقعك يطلع هناك.
3. جوجل: console.cloud.google.com ← مشروع جديد ← فعّل YouTube Data API v3 ←
   OAuth consent screen (External، أضف نفسك Test user) ← Credentials ← OAuth client ID نوع Desktop ←
   نزّل الملف وسمّه client_secret.json بجانب get_refresh_token.py.
4. على جهازك: pip install google-auth-oauthlib ثم python get_refresh_token.py ← سجل دخول بحساب القناة ← انسخ الـ refresh token.
5. في الريبو: Settings ← Secrets and variables ← Actions ← أضف:
   YT_CLIENT_ID , YT_CLIENT_SECRET , YT_REFRESH_TOKEN
6. Token للموقع: GitHub ← Settings ← Developer settings ← Fine-grained tokens ← صلاحية Contents (Read and write) لهذا الريبو فقط.
7. افتح موقعك، ادخل اسمك واسم الريبو والـ token، أضف فيديوهات الأيام.
8. للتجربة: تبويب Actions ← Daily Quran Video ← Run workflow.

ملاحظات:
- السكربت يشتغل 7 صباحاً بغداد، يجهز الفيديو ويرفعه كـ Private مع جدولة نشر (publishAt) بوقت عشوائي ضمن PUBLISH_FROM و PUBLISH_TO، أو بالوقت اللي تحدده من الموقع. غيّر الفترة من daily.yml.
- للتجربة بدون جدولة حط PRIVACY: private بملف daily.yml.
- لو المشروع جديد، جوجل يخلي الفيديوهات خاصة (Private) لحد ما تقدم طلب تدقيق للـ API. ابدأ بـ PRIVACY: private للتجربة.
- التطبيق بوضع Testing يلغي الـ refresh token كل 7 أيام؛ اضغط Publish app بشاشة OAuth consent حتى يدوم.

- قارئ جديد: شغّل `python find_reciter.py اسم_بالانكليزي` لتعرف اسم المجلد على EveryAyah، وبعدها اختر (قارئ آخر) من الموقع وألصق الاسم.

## قارئ مو موجود بـ EveryAyah (مثل عبد الرحمن مسعد)
- من الموقع اختر (قارئ آخر) والصق **رابط mp3 مباشر للسورة كاملة** واسم القارئ بالعربي.
- السكربت يقسم السورة إلى آيات تلقائياً عند أطول الوقفات (يهمل البسملة بأول السورة).
- إذا القارئ يبدأ بالاستعاذة أو مقدمة: أضف بالـ schedule.json حقل "skip_start": 5 (ثواني تُقص من البداية).
- إذا التقطيع طلع غلط: حدد التوقيتات يدوياً لكل آية بالمدى المطلوب، مثال: "timings": ["0-6.4","6.4-12.1","12.1-20"]
- التقطيع بالصمت تقريبي: ممتاز للقراء البطيئين الواضحين، وأضعف مع السور الطويلة جداً أو القراء السريعين. شاهد أول فيديو قبل ما تعتمد عليه.

## الوضع التلقائي الكامل
- كل يوم السكربت يختار الآيات لحاله ويسوي الفيديو وينشره بوقت عشوائي. ما تحتاج تدخل الموقع.
- `AUTO_MODE: sequential` يكمل القرآن بالترتيب من وين وقف (محفوظ بـ auto_state.json)، و`random` يختار سورة وآيات عشوائية.
- `AUTO_AYAHS` عدد الآيات بكل فيديو (الافتراضي 5).
- القارئ يتغير عشوائياً بين القراء الستة. لو تريد قراء معينين: AUTO_RECITERS: "Alafasy_128kbps,Husary_128kbps"
- الموقع صار اختياري: تستخدمه فقط إذا تريد يوم معين بآيات أو قارئ أو وقت محدد، ويتغلب على الوضع التلقائي.

## فيديو طويل يدوي (أفقي 1920×1080)
- من الموقع: بطاقة (فيديو طويل) ← اختر السورة والآيات والقارئ ← جهّز الفيديو. (يحتاج token بصلاحية Actions أيضاً.)
- أو من GitHub: Actions ← Long Video (manual) ← Run workflow.
- بعد دقائق: افتح التشغيل المنتهي ← Artifacts ← quran-long-video ← نزّله وارفعه على يوتيوب بنفسك. ما يترفع تلقائياً.
- الملف يبقى 7 أيام. وإذا الفرع مو main، غيّر ref بملف index.html.
